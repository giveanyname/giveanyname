package objects;

public class Rectangle {

}
